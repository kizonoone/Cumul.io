// Importing http libraries
var http = require('http');
var fs = require('fs')

// Creating a server
const server = http.createServer((req, res) => {
	const url = req.url;
	const method = req.method;

    if (req.headers['x-secret'] != SECRET) {
        res.write('lSecret correct')
        console.log(JSON.stringify(res.headers)); //output the headers before exit
        res.end();
    }

    if (url === '/') {
		// Sending the response
		res.write('<html>');
		res.write('<head><title>Enter Message</title><head>');
		res.write(`<body><form action="/message" method="POST">
	    <input type="text" name="message"></input>
	    <button type="submit">Send</button></form></body></html>`);
		res.write('</html>');
		return res.end();
	}

	// Handling different routes for different type request
	if (url === '/message' && method === 'POST') {
		const body = [];

		req.on('data', (chunk) => {
			// Storing the chunk data
			body.push(chunk);
			console.log(body)
		});

		req.on('end', () => {
			// Parsing the chunk data
			parsedBody = Buffer.concat(body).toString();
            fs.writeFileSync("file.txt",parsedBody)//sending the message to the file
			const message = parsedBody.split('=')[1];		
			// Printing the data
			console.log(message);
		});

		res.statusCode = 302;
		res.setHeader('Location', '/');
        res.writeHead(200)
		return res.end('OK');
	}
});

// Starting the server
server.listen(7654);
